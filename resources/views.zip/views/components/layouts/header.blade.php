<header class="header ">
    <img class="max-h-full" src="{{asset("images/logo.jpeg")}}" alt="logo">
    <h1 class = "text-white text-5xl" > GESTIÓN INSITITUTO</h1>
    <div>
        @auth
            <span class="text-white">{{ auth()->user()->name }}
            <form action="{{route("logout")}}" method="POST">
                @csrf
                <input class="btn  btn-glass" type="submit" value="Logout">
            </form>
            Logout

        @endauth
        @guest
                <a class="btn  btn-glass" href="{{route("login")}}">Login</a>
                <a class="btn  btn-glass" href="{{route("register")}}">Register</a>
        @endguest

    </div>

</header>
