<nav class ="h-10v bg-nav
flex flex-row space-x-2 items-center px-3 justify-start" >
    <a class="btn btn-sm btn-primary" href="">About</a>
    <a class="btn btn-sm btn-warning" href="">Contacta</a>
    <a class="btn btn-sm btn-primary" href="">Noticias</a>
    <a class="btn btn-sm btn-warning" href="">Referencias</a>
</nav>
